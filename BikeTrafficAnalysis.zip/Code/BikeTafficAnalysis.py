# Importing Packages
import pandas as pd
import numpy as np
import re
import category_encoders as ce
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression,LogisticRegression
from sklearn.metrics import mean_squared_error,confusion_matrix
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn import tree
import warnings
import statsmodels.api as sm
warnings.filterwarnings("ignore") 
import random
random.seed(10)
import seaborn as sns

# Importing Datasets
df_bicycle = pd.read_csv('../Data/NYC_Bicycle_Counts_2016_Corrected.csv')

# Question 1
def Question1(X,Y):
    def preprocessing_df_1(X,Y):

        # Ordinal Encoding
        def ordinal_encoding(df,col,mapping):
            ordinal_encoder=ce.OrdinalEncoder(cols=col,return_df=True,mapping=[{'col':col,'mapping':mapping}])
            df_final = ordinal_encoder.fit_transform(df)
            return df_final

        # Preprocessing Data
        X = df_bicycle[X]
        Y = df_bicycle[Y]

        # Dependent Variable column Name
        Y_Name = Y.columns[0]

        # Applying Ordinal encoding Function
        X = ordinal_encoding(X,"Day",{"Monday":1,"Tuesday":2,"Wednesday":3,"Thursday":4,"Friday":5,"Saturday":6,"Sunday":7})\
        
        # Cleaning Precipitation column
        for i,j in enumerate(X["Precipitation"]):
            if j == "0.47 (S)":
                X["Precipitation"].iloc[i] = 0.47
            if j == "T":
                X["Precipitation"].iloc[i] = 0
        # Replacing comma with blank
        X = X.replace(',','', regex=True)
        Y = Y.replace(',','', regex=True)

        # Standardization
        scaler = StandardScaler()
        X = scaler.fit_transform(X)
        Y = scaler.fit_transform(Y)
        return X,Y,Y_Name


    def model_1(X,Y):
        # Applying Preprocessing
        X,Y,Y_Name = preprocessing_df_1(X,Y)

        # Train Test Split
        X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.25, random_state=101)
        parameter = range(2,10)
        model_details = []
        rmse_details = []
        for l in parameter:
            #Train the regression model using a regularization parameter of l
             # Decision Tree Regressor
            model = DecisionTreeRegressor(min_samples_split = l,max_depth =l)

            # Fitting Data in the model
            model.fit(X_train,y_train)

            # Predictions
            Y_pred = model.predict(X_test)

            # RMSE Error
            rmse = round(np.sqrt(mean_squared_error(Y_pred,y_test)),3)

            #Store the model and mse in lists for further processing
            model_details.append(model)
            rmse_details.append(rmse)
        #Plot the MSE as a function of lmbda
        plt.plot(parameter,rmse_details,color='blue',linewidth=1,label='MSE as function of lmbda') #fill in
        plt.title(f"Target Variable : {Y_Name}  \n RMSE versus Max Depth value")
        plt.xlabel("Max Depth")
        plt.ylabel("RMSE ")
        plt.show()
        #Find best value of lmbda in terms of MSE
        index = rmse_details.index(min(rmse_details))#fill in
        [parameter_best,rmse_best,model_best] = [parameter[index],rmse_details[index],model_details[index]]
        print('RMSE with ' + Y_Name + ' as target variable is ' + str(rmse_best)+ '. The best parameter value tested for it is ' + str(parameter_best))
    model_1(X,Y)

# From the output, we can that Brooklyn Bridge, Manhattan Bridge, Queensboro Bridge estimate the overall traffic with lower RMSE value .
# Therefore, I choose install sensor on Brooklyn Bridge, Manhattan Bridge, and Queensboro Bridge

# Question 2
def Question2(X,Y):
    def preprocessing_df_2(X,Y):
        # Preprocessing Data
        X = df_bicycle[X]
        Y = df_bicycle[Y]

        # Cleaning Precipitation Column
        for i,j in enumerate(X["Precipitation"]):
            if j == "0.47 (S)":
                X["Precipitation"].iloc[i] = 0.47
            if j == "T":
                X["Precipitation"].iloc[i] = 0
        
        # Replacing comma with blank
        X = X.replace(',','', regex=True)
        Y = Y.replace(',','', regex=True)
        X_df = pd.DataFrame(X)
        Y_df = pd.DataFrame(Y)
        df_temp  = pd.concat([X_df,Y_df],axis =1)
        df_temp.columns = ["Precipitation","High Temp (°F)","Low Temp (°F)","Total"]
        print(df_temp.dtypes)
        df_temp["Precipitation"] = df_temp["Precipitation"].astype(str).astype(float)
        df_temp["Total"] = df_temp["Total"].astype(str).astype(float)
        sns.regplot(x='Precipitation', y='Total', data=df_temp)
        plt.show()
        sns.regplot(x='High Temp (°F)', y='Total', data=df_temp)
        plt.show()
        sns.regplot(x='Low Temp (°F)', y='Total', data=df_temp)
        plt.show()
        return X,Y



    def model_2(X,Y):
        # Applying Preprocessing functiuon
        X,Y = preprocessing_df_2(X,Y)
        regression = LinearRegression()

        # Regression on the original data
        regression.fit(X[['High Temp (°F)','Low Temp (°F)','Precipitation']], Y)

        # Intercepts of the model
        intercept =regression.intercept_

        # Coefficients of the model
        coef = regression.coef_
        
        # Ordinary Least Squares regression
        X = sm.add_constant(X[['High Temp (°F)','Low Temp (°F)','Precipitation']])
        model = sm.OLS(Y.astype(float),X.astype(float)).fit()
        print(model.summary())
        
        # Regression Equation
        print("Regression Equation :",np.round(coef[0][0],2),"* High Temp (°F)",np.round(coef[0][1],2),"* Low Temp (°F)",np.round(coef[0][2],2),"* Precipitation"," + ", np.round(intercept[0],2))

    model_2(X,Y)

# From the output, we can see that R Squared Value = 0.499 for our model. 
# From this we can state that 50 % of dependent variable value can be explained by the independent variables. 
# So we conclude that they can use weather data to predict bicyclists in a day

# Question 3
def Question3(X,Y):
    def preprocessing_df_3(X,Y):
        # Preprocessing Data
        X = df_bicycle[X]
        Y = df_bicycle[Y]

        # Cleaning Precipitation column
        for i,j in enumerate(Y["Precipitation"]):
            if j == "0.47 (S)":
                Y["Precipitation"].iloc[i] = 0.47
            if j == "T":
                Y["Precipitation"].iloc[i] = 0

        # Converting from string to float
        Y["Precipitation"] = Y["Precipitation"].astype(float)

        # Binning
        for j,i in enumerate(Y["Precipitation"]):
            if i >= 0.5:
                Y["Precipitation"].iloc[j] = 1
            else:
                Y["Precipitation"].iloc[j] = 0
        
        # Replacing comma with blank space
        X = X.replace(',','', regex=True)
        Y = Y.replace(',','', regex=True)
        return X,Y

    def model_3(X,Y):
        # Applying Preprocessing
        X,Y = preprocessing_df_3(X,Y)

        # Train Test Split
        X_train, X_test, y_train, y_test = train_test_split(X,Y,train_size=0.75,random_state= 5,stratify = Y)

        # Logistic Regression Model
        log_model = LogisticRegression()

        # Fitting data
        log_model.fit(X_train,y_train)

        # Preictions
        y_pred = log_model.predict(X_test)
       
        # Converting series to array
        y_test = np.array(y_test)
        y_pred = np.array(y_pred)

        # Accuracy Score 
        score = log_model.score(X_test,y_test)

        print("Coefficients : ",log_model.coef_[0][0])
        print("Intercepts : ",log_model.intercept_[0])
        print('Accuracy Score : ' +str(score))
        cf_matrix = confusion_matrix(y_test, y_pred)
        sns.heatmap(cf_matrix, annot=True)
        plt.show()

    model_3(X,Y)


# In the Output, we can see that accuracy is around 95% for our model. So we can use this data to predict whether it is raining based on the number of bicyclists on the bridges

if __name__ == '__main__':
    print("\n")
    print("------------------------------- Question 1-------------------------------------")
    print("\n")
    Question1(['Day','Precipitation','High Temp (°F)','Low Temp (°F)','Brooklyn Bridge','Manhattan Bridge','Williamsburg Bridge'],['Queensboro Bridge'])
    Question1(['Day','Precipitation','High Temp (°F)','Low Temp (°F)','Brooklyn Bridge','Manhattan Bridge','Queensboro Bridge'],['Williamsburg Bridge'])
    Question1(['Day','Precipitation','High Temp (°F)','Low Temp (°F)','Brooklyn Bridge','Queensboro Bridge','Williamsburg Bridge'],['Manhattan Bridge'])
    Question1(['Day','Precipitation','High Temp (°F)','Low Temp (°F)','Queensboro Bridge','Manhattan Bridge','Williamsburg Bridge'],['Brooklyn Bridge'])
    print("\n")
    print("------------------------------- Question 2-------------------------------------")
    print("\n")
    Question2(['Precipitation','High Temp (°F)','Low Temp (°F)'],["Total"])
    print("\n")
    print("------------------------------- Question 3-------------------------------------")
    print("\n")
    Question3(["Total"],["Precipitation"])
    print("\n")