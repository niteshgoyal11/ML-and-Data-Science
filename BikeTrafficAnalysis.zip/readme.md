
# Bike Traffic Analysis

First, Install all the requirements needed

```
pip install -r requirements.txt
```

Then move into the Code Folder

```
cd Code
```
Now execute the BikeTrafficAnalysis.py program

```
python BikeTafficAnalysis.py 
```

Your app will be executing and priniting outputs for all 3 Questions